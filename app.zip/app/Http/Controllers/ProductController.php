<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\Shop;

class ProductController extends Controller
{
    public function home()
    {
        $dogFoods = Product::where('category', 'Dog Food')->get();
        $catFoods = Product::where('category', 'Cat Food')->get();
        $petGroomingSupplies = Product::where('category', 'Pet Grooming Supplies')->get();
        $petHealthWellness = Product::where('category', 'Pet Health & Wellness')->get();
        $littersAccessories = Product::where('category', 'Litters & Accessories')->get();

        return view('home', compact('dogFoods', 'catFoods', 'petGroomingSupplies', 'petHealthWellness', 'littersAccessories'));
    }
    public function search(Request $request)
    {
        $query = $request->input('query');
        $products = Product::where('name', 'LIKE', "%{$query}%")->get();

        return response()->json($products);
    }
    
}
